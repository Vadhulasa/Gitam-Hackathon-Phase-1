import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

public class reg extends HttpServlet {

    // Function to redirect to a specific URL
    private void redirectTo(HttpServletResponse res, String url) throws IOException {
        res.sendRedirect(url);
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter pw = res.getWriter();
        
        // Get data from form fields
        String fname = req.getParameter("full-name");
        String email = req.getParameter("email");
        String nm = req.getParameter("username");
        String phn = req.getParameter("phone");
        String pass = req.getParameter("password");
        String confirmpass = req.getParameter("confirm-password");
        
        // Check if password and confirm password match
        if(pass.equals(confirmpass)) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tasks", "root", "");
                PreparedStatement pstmt = con.prepareStatement("INSERT INTO data (full_name, email, username, phone, password) VALUES (?, ?, ?, ?, ?)");
                pstmt.setString(1, fname);
                pstmt.setString(2, email);
                pstmt.setString(3, nm);
                pstmt.setString(4, phn);
                pstmt.setString(5, pass);

                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
pw.println("<p>Redirecting...</p>");
pw.println("<script>setTimeout(function() { window.location.href = 'index.html'; }, 1000);</script>");

                } else {
                    pw.println("Failed to insert data.");
                }

                con.close();
            } catch (Exception e) {
                pw.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            pw.println("<script>alert('Password and Confirm Password must match');</script>");
	    pw.println("<script>setTimeout(function() { window.location.href = 'index.html'; }, 0);</script>");
        }
    }
}
