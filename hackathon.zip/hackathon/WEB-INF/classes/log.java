import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

public class log extends HttpServlet {

    // Function to redirect to a specific URL
    private void redirectTo(HttpServletResponse res, String url) throws IOException {
        res.sendRedirect(url);
    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter pw = res.getWriter();
        
        // Get username and password from form fields
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        
        // Provide your database and table names
        String dbName = "tasks";
        String tableName = "data";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, "root", "");
            PreparedStatement pstmt = con.prepareStatement("SELECT * FROM " + tableName + " WHERE username = ? AND password = ?");
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Login successful
                pw.println("<script>alert('Login successful!');</script>");
                // Redirect to the dashboard or any other page after successful login
		pw.println("<p>Redirecting...</p>");
		pw.println("<script>setTimeout(function() { window.location.href = 'AdminLTE-master/index.html'; }, 1000);</script>");
            } else {
                // Login failed
                pw.println("<script>alert('Invalid username or password');</script>");
                // Redirect back to the login page
		pw.println("<p>Redirecting...</p>");
		pw.println("<script>setTimeout(function() { window.location.href = 'index.html'; }, 1000);</script>");
            }

            con.close();
        } catch (Exception e) {
            pw.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
